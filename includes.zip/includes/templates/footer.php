        <footer class="site-tail">
            <div class="container tail__address">
                &copy; <?= date('Y') ?> TalkHub. Todos los derechos reservados.
            </div>
        </footer>
        <script src="/build/js/bundle.min.js"></script>
    </body>
</html>