<body>
    <header class="site-header secondary">
        <div class="container nav">
            <a class="brand" href="/"><img src="/build/img/logo.webp" alt="Talk-Hub"></a>
            <button class="nav-toggle" aria-label="Abrir menú" id="navToggle">☰</button>
            <nav class="menu" id="mainNav">
                <a href="panel_agente.php">Inicio</a>
                <a href="ver_mis_tickets.php">Tickets</a>
                <a href="biblioteca.php">Biblioteca</a>
                <a href="autoservicio.php">Soluciones</a>
                <a class="btn-primary" href="logout.php">Cerrar Sesion</a>
            </nav>
        </div>
    </header>