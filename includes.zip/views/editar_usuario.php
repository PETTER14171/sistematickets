<?php
include __DIR__ . '/../includes/config/verificar_sesion.php';
include __DIR__ . '/../includes/config/conexion.php';

if ($_SESSION['rol'] !== 'tecnico') {
    header("Location: index.php?error=Acceso denegado");
    exit;
}

$id_usuario = isset($_GET['id']) ? intval($_GET['id']) : 0;
$mensaje = "";

// Obtener usuario actual
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();
$stmt->close();

if (!$usuario) {
    die("❌ Usuario no encontrado.");
}

// Si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre  = trim($_POST['nombre']);
    $correo  = trim($_POST['correo']);
    $rol     = $_POST['rol'];
    $activo  = isset($_POST['activo']) ? 1 : 0;
    $campana = trim($_POST['campana']);
    $puesto  = trim($_POST['puesto']);
    $estacion = trim($_POST['estacion']);

    // Nuevo: flag de acceso a biblioteca
    $acceso_biblioteca = isset($_POST['acceso_biblioteca']) ? 1 : 0;

    // Validar correo único (excepto si es el mismo usuario)
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ? AND id != ?");
    $stmt->bind_param("si", $correo, $id_usuario);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $mensaje = "⚠️ Ya existe otro usuario con este correo.";
    } else {
        $stmt->close();

        // Actualizar datos del usuario, incluyendo acceso_biblioteca
        $stmt = $conn->prepare(
            "UPDATE usuarios 
             SET nombre = ?, correo = ?, rol = ?, activo = ?, campana = ?, puesto = ?, estacion = ?, acceso_biblioteca = ?
             WHERE id = ?"
        );
        // Tipos: s s s i s s s i i
        $stmt->bind_param(
            "sssisssii",
            $nombre,
            $correo,
            $rol,
            $activo,
            $campana,
            $puesto,
            $estacion,
            $acceso_biblioteca,
            $id_usuario
        );

        if ($stmt->execute()) {
            $mensaje = "✅ Usuario actualizado correctamente.";
            // Actualizar datos locales para que el formulario refleje lo guardado
            $usuario = [
                'id'                 => $id_usuario,
                'nombre'             => $nombre,
                'correo'             => $correo,
                'rol'                => $rol,
                'activo'             => $activo,
                'campana'            => $campana,
                'puesto'             => $puesto,
                'estacion'           => $estacion,
                'acceso_biblioteca'  => $acceso_biblioteca
            ];
        } else {
            $mensaje = "❌ Error al actualizar el usuario.";
        }
        $stmt->close();
    }
}
?>

<?php
    require_once __DIR__ . '/../includes/funciones.php';
    incluirTemplate('head', [
        'page_title' => 'Editar Ususario',
        'page_desc'  => 'Panel para que el Tecnico edite un usuario'
    ]);
    incluirTemplate('header');
?>

<main class="admin-tickets-page falla-edit-page">
  <a href="usuarios.php" class="btn-1 btn-volver ticket-detail__back">← Volver</a>
    <section class="admin-tickets__inner">
      <header class="admin-tickets__header">
          <div class="admin-tickets__title-group">
              <h1 class="admin-tickets__title">Editar Usuario</h1>
              <p class="admin-tickets__subtitle">
                  Actualiza la informacion del usuario.
              </p>
          </div>
      </header>
      <?php if ($mensaje): ?>
          <div class="mensaje"><?= htmlspecialchars($mensaje) ?></div>
      <?php endif; ?>

      <section class="admin-tickets-card nombre-falla">
        <form class="form-usuario" method="POST">
          <!-- Nombre -->
          <section class="contenido-bloque nombre-falla">
            <div class="field">
              <input
                id="nombre"
                class="field__input"
                type="text"
                name="nombre"
                placeholder=" "
                value="<?= htmlspecialchars($usuario['nombre'] ?? '') ?>"
                required
              >
              <label for="nombre" class="field__label">Nombre</label>
            </div>
          </section>

          <!-- Correo -->
          <section class="contenido-bloque correo-falla">
            <div class="field">
              <input
                id="correo"
                class="field__input"
                type="email"
                name="correo"
                placeholder=" "
                value="<?= htmlspecialchars($usuario['correo'] ?? '') ?>"
                required
              >
              <label for="correo" class="field__label">Correo electrónico</label>
            </div>
          </section>

          <!-- Rol -->
          <section class="contenido-bloque rol-falla">
            <div class="field">
              <select
                id="rol"
                class="field__input field__select"
                name="rol"
                required
              >
                <option value="" disabled>Selecciona un rol</option>
                <option value="agente"  <?= ($usuario['rol'] ?? '') === 'agente'  ? 'selected' : '' ?>>Agente</option>
                <option value="tecnico" <?= ($usuario['rol'] ?? '') === 'tecnico' ? 'selected' : '' ?>>Técnico</option>
                <option value="admin"   <?= ($usuario['rol'] ?? '') === 'admin'   ? 'selected' : '' ?>>Administrador</option>
              </select>
              <label for="rol" class="field__label">Rol</label>
            </div>
          </section>

          <!-- Campaña -->
          <section class="contenido-bloque campana-falla">
            <div class="field">
              <input
                id="campana"
                class="field__input"
                type="text"
                name="campana"
                placeholder=" "
                value="<?= htmlspecialchars($usuario['campana'] ?? '') ?>"
              >
              <label for="campana" class="field__label">Campaña</label>
            </div>
          </section>

          <!-- Puesto -->
          <section class="contenido-bloque puesto-falla">
            <div class="field">
              <input
                id="puesto"
                class="field__input"
                type="text"
                name="puesto"
                placeholder=" "
                value="<?= htmlspecialchars($usuario['puesto'] ?? '') ?>"
              >
              <label for="puesto" class="field__label">Puesto</label>
            </div>
          </section>

          <!-- Estación -->
          <section class="contenido-bloque estacion-falla">
            <div class="field">
              <input
                id="estacion"
                class="field__input"
                type="text"
                name="estacion"
                placeholder=" "
                value="<?= htmlspecialchars($usuario['estacion'] ?? '') ?>"
              >
              <label for="estacion" class="field__label">Estación</label>
            </div>
          </section>

          <!-- Usuario activo (switch) -->
          <section class="contenido-bloque activo-falla">
            <div class="switch">
              <input
                id="activo"
                class="switch__input"
                type="checkbox"
                name="activo"
                <?= !empty($usuario['activo']) ? 'checked' : '' ?>
              >
              <label for="activo" class="switch__label">
                <span class="switch__title">Usuario activo</span>
              </label>
            </div>
          </section>

          <!-- Acceso a biblioteca (switch) -->
          <section class="contenido-bloque biblioteca-falla">
            <div class="switch">
              <input
                id="acceso_biblioteca"
                class="switch__input"
                type="checkbox"
                name="acceso_biblioteca"
                <?= !empty($usuario['acceso_biblioteca']) ? 'checked' : '' ?>
              >
              <label for="acceso_biblioteca" class="switch__label">
                <span class="switch__title">Acceso a biblioteca</span>
              </label>
            </div>
          </section>

          <!-- Botón -->
          <div class="form-falla__actions">
            <button class="btn-primary" type="submit">Guardar cambios</button>
          </div>
        </form>
      </section>
    </section>
</main>
<?php 
incluirTemplate('footer');
?>
